<?php
namespace App\Controllers;
use App\Models\PdModel;
use CodeIgniter\API\ResponseTrait;

class Pd extends BaseController {
    use ResponseTrait;
    protected $model;
    public function __construct() { $this->model = new PdModel(); }
    public function index() { return $this->respond(['status' => true, 'data' => $this->model->findAll()]); }
    public function show($id = null) {
        $data = $this->model->find($id);
        if (!$data) return $this->failNotFound('Data tidak ditemukan');
        return $this->respond(['status' => true, 'data' => $data]);
    }
    public function create() {
        $data = $this->request->getJSON(true) ?? $this->request->getPost();
        if (!$this->model->insert($data)) return $this->failValidationErrors($this->model->errors());
        return $this->respondCreated(['status' => true, 'message' => 'Berhasil ditambah']);
    }
    public function update($id = null) {
        $data = $this->request->getJSON(true) ?? $this->request->getRawInput();
        if (!$this->model->update($id, $data)) return $this->failValidationErrors($this->model->errors());
        return $this->respond(['status' => true, 'message' => 'Berhasil diupdate']);
    }
    public function delete($id = null) {
        $this->model->delete($id);
        return $this->respondDeleted(['status' => true, 'message' => 'Berhasil dihapus']);
    }

    // PATCH /api/pd/1/alamat
    public function updateAlamat($id = null) {
    $data = $this->request->getJSON(true) ?? $this->request->getRawInput();
    if (!$this->model->update($id, ['alamat' => $data['alamat'] ?? null])) {
        return $this->failValidationErrors($this->model->errors());
    }
    return $this->respond(['status' => true, 'message' => 'Alamat berhasil diupdate']);
}
}