<?php
namespace App\Models;
use CodeIgniter\Model;
class KdoModel extends Model {
    protected $table = 'kdo';
    protected $primaryKey = 'id_kdo';
    protected $allowedFields = ['plat_nomor','merk','tipe','tahun','warna','id_pd','id_pns','status'];
    protected $useTimestamps = true;
}