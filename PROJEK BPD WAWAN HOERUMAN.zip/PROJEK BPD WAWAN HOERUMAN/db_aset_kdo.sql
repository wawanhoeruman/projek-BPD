-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2026 at 06:09 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_aset_kdo`
--

-- --------------------------------------------------------

--
-- Table structure for table `kdo`
--

CREATE TABLE `kdo` (
  `id_kdo` int(11) NOT NULL,
  `plat_nomor` varchar(15) NOT NULL,
  `merk` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL,
  `tahun` int(11) NOT NULL,
  `warna` varchar(30) DEFAULT NULL,
  `id_pd` int(11) NOT NULL,
  `id_pns` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'Aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kdo`
--

INSERT INTO `kdo` (`id_kdo`, `plat_nomor`, `merk`, `tipe`, `tahun`, `warna`, `id_pd`, `id_pns`, `status`, `created_at`, `updated_at`) VALUES
(1, 'B 1234 ABC', 'Toyota', 'Avanza', 2021, 'Hitam', 1, 1, 'Perbaikan', '2026-11-14 04:24:05', '2026-11-13 22:52:10'),
(2, 'B 5678 DEF', 'Daihatsu', 'Xenia', 2020, 'Putih', 1, 2, 'Aktif', '2026-11-14 04:24:05', '2026-11-14 04:24:05'),
(3, 'B 9012 GHI', 'Toyota', 'Innova', 2022, 'Silver', 2, 3, 'Perbaikan', '2026-11-14 04:24:05', '2026-11-14 04:24:05'),
(5, 'B 7890 MNO', 'Mitsubishi', 'Xpander', 2023, 'Hitam', 4, 1, 'Aktif', '2026-11-14 04:24:05', '2026-11-14 04:24:05'),
(6, 'B 9999 ZZZ', 'Honda', 'Brio', 2023, 'Merah', 1, 1, 'Aktif', '2026-11-13 22:14:47', '2026-11-13 22:14:47');

-- --------------------------------------------------------

--
-- Table structure for table `pd`
--

CREATE TABLE `pd` (
  `id_pd` int(11) NOT NULL,
  `kode_pd` varchar(20) NOT NULL,
  `nama_pd` varchar(100) NOT NULL,
  `alamat` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pd`
--

INSERT INTO `pd` (`id_pd`, `kode_pd`, `nama_pd`, `alamat`, `created_at`, `updated_at`) VALUES
(1, 'BPAD', 'Badan Pengelolaan Aset Daerah', 'Jl. Baru No. 99, Jakarta', '2026-11-14 04:24:05', '2026-11-13 22:52:49'),
(2, 'DISHUB', 'Dinas Perhubungan', 'Jl. Abdul Muis No. 66, Jakarta Pusat', '2026-11-14 04:24:05', '2026-11-14 04:24:05'),
(3, 'DINKES', 'Dinas Kesehatan', 'Jl. Kesehatan No. 10, Jakarta Pusat', '2026-11-14 04:24:05', '2026-11-14 04:24:05'),
(4, 'DISKOMINFOTIK', 'Bagian Umum', 'Jl. Medan Merdeka Selatan No. 8-9, Jakarta Pusat', '2026-11-14 04:24:05', '2026-11-13 22:34:29'),
(5, '', 'Bagian Umum', NULL, '2026-11-13 22:17:14', '2026-11-13 22:17:14');

-- --------------------------------------------------------

--
-- Table structure for table `pns`
--

CREATE TABLE `pns` (
  `id_pns` int(11) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama_pns` varchar(100) NOT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `id_pd` int(11) NOT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pns`
--

INSERT INTO `pns` (`id_pns`, `nip`, `nama_pns`, `jabatan`, `id_pd`, `no_hp`, `created_at`, `updated_at`) VALUES
(1, '198501010201001001', 'Ahmad Fauzi - EDIT', 'Kepala Bidang Aset', 1, '081234567890', '2026-11-14 04:24:05', '2026-11-13 22:50:50'),
(2, '198803152011022002', 'Siti Rahmawati', 'Staf Pengelola Kendaraan', 1, '081234567802', '2026-11-14 04:24:05', '2026-11-14 04:24:05'),
(3, '199001202015031003', 'Budi Santoso', 'Kepala Seksi Transportasi', 2, '081234567803', '2026-11-14 04:24:05', '2026-11-14 04:24:05'),
(5, '199001011234', 'Test Doang', 'Staff', 1, '081234567899', '2026-11-13 22:16:02', '2026-11-13 22:16:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kdo`
--
ALTER TABLE `kdo`
  ADD PRIMARY KEY (`id_kdo`),
  ADD UNIQUE KEY `plat_nomor` (`plat_nomor`),
  ADD KEY `id_pd` (`id_pd`),
  ADD KEY `id_pns` (`id_pns`);

--
-- Indexes for table `pd`
--
ALTER TABLE `pd`
  ADD PRIMARY KEY (`id_pd`),
  ADD UNIQUE KEY `kode_pd` (`kode_pd`);

--
-- Indexes for table `pns`
--
ALTER TABLE `pns`
  ADD PRIMARY KEY (`id_pns`),
  ADD UNIQUE KEY `nip` (`nip`),
  ADD KEY `id_pd` (`id_pd`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kdo`
--
ALTER TABLE `kdo`
  MODIFY `id_kdo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pd`
--
ALTER TABLE `pd`
  MODIFY `id_pd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pns`
--
ALTER TABLE `pns`
  MODIFY `id_pns` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kdo`
--
ALTER TABLE `kdo`
  ADD CONSTRAINT `kdo_ibfk_1` FOREIGN KEY (`id_pd`) REFERENCES `pd` (`id_pd`) ON UPDATE CASCADE,
  ADD CONSTRAINT `kdo_ibfk_2` FOREIGN KEY (`id_pns`) REFERENCES `pns` (`id_pns`) ON UPDATE CASCADE;

--
-- Constraints for table `pns`
--
ALTER TABLE `pns`
  ADD CONSTRAINT `pns_ibfk_1` FOREIGN KEY (`id_pd`) REFERENCES `pd` (`id_pd`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
