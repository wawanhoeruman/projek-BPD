<?php
namespace App\Models;
use CodeIgniter\Model;
class PdModel extends Model {
    protected $table = 'pd';
    protected $primaryKey = 'id_pd';
    protected $allowedFields = ['kode_pd','nama_pd','alamat'];
    protected $useTimestamps = true;
}