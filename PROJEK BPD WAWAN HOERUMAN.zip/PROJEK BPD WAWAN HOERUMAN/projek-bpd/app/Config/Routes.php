<?php
use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->group('api', function($routes){
    $routes->resource('kdo', ['controller' => 'Kdo']);
    $routes->resource('pns', ['controller' => 'Pns']);
    $routes->resource('pd', ['controller' => 'Pd']);
    $routes->patch('kdo/(:num)/status', 'Kdo::updateStatus/$1');
    $routes->patch('pns/(:num)/jabatan', 'Pns::updateJabatan/$1');
    $routes->patch('pd/(:num)/alamat', 'Pd::updateAlamat/$1');
});