<?php
namespace App\Controllers;
use App\Models\KdoModel;
use CodeIgniter\API\ResponseTrait;

class Kdo extends BaseController {
    use ResponseTrait;
    protected $model;

    public function __construct() {
        $this->model = new KdoModel();
    }

    // GET /api/kdo
    public function index() {
        $data = $this->model->findAll();
        return $this->respond(['status' => true, 'data' => $data]);
    }

    // GET /api/kdo/1
    public function show($id = null) {
        $data = $this->model->find($id);
        if (!$data) return $this->failNotFound('Data tidak ditemukan');
        return $this->respond(['status' => true, 'data' => $data]);
    }

    // POST /api/kdo
    public function create() {
        $data = $this->request->getJSON(true) ?? $this->request->getPost();
        if (!$this->model->insert($data)) {
            return $this->failValidationErrors($this->model->errors());
        }
        return $this->respondCreated(['status' => true, 'message' => 'Berhasil ditambah']);
    }

    // PUT /api/kdo/1
    public function update($id = null) {
        $data = $this->request->getJSON(true) ?? $this->request->getRawInput();
        if (!$this->model->update($id, $data)) {
            return $this->failValidationErrors($this->model->errors());
        }
        return $this->respond(['status' => true, 'message' => 'Berhasil diupdate']);
    }

    // DELETE /api/kdo/1
    public function delete($id = null) {
        $this->model->delete($id);
        return $this->respondDeleted(['status' => true, 'message' => 'Berhasil dihapus']);
    }

    // PATCH /api/kdo/1/status
    public function updateStatus($id = null) {
    $data = $this->request->getJSON(true) ?? $this->request->getRawInput();
    if (!$this->model->update($id, ['status' => $data['status'] ?? null])) {
        return $this->failValidationErrors($this->model->errors());
    }
    return $this->respond(['status' => true, 'message' => 'Status berhasil diupdate']);
}
}