<?php
namespace App\Controllers;
use App\Models\PnsModel;
use CodeIgniter\API\ResponseTrait;

class Pns extends BaseController {
    use ResponseTrait;
    protected $model;
    public function __construct() { $this->model = new PnsModel(); }
    public function index() { return $this->respond(['status' => true, 'data' => $this->model->findAll()]); }
    public function show($id = null) {
        $data = $this->model->find($id);
        if (!$data) return $this->failNotFound('Data tidak ditemukan');
        return $this->respond(['status' => true, 'data' => $data]);
    }
    public function create() {
        $data = $this->request->getJSON(true) ?? $this->request->getPost();
        if (!$this->model->insert($data)) return $this->failValidationErrors($this->model->errors());
        return $this->respondCreated(['status' => true, 'message' => 'Berhasil ditambah']);
    }
    public function update($id = null) {
        $data = $this->request->getJSON(true) ?? $this->request->getRawInput();
        if (!$this->model->update($id, $data)) return $this->failValidationErrors($this->model->errors());
        return $this->respond(['status' => true, 'message' => 'Berhasil diupdate']);
    }
    public function delete($id = null) {
        $this->model->delete($id);
        return $this->respondDeleted(['status' => true, 'message' => 'Berhasil dihapus']);
    }

    // PATCH /api/pns/1/jabatan
    public function updateJabatan($id = null) {
    $data = $this->request->getJSON(true) ?? $this->request->getRawInput();
    if (!$this->model->update($id, ['jabatan' => $data['jabatan'] ?? null])) {
        return $this->failValidationErrors($this->model->errors());
    }
    return $this->respond(['status' => true, 'message' => 'Jabatan berhasil diupdate']);
}
}