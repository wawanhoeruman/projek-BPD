<?php
namespace App\Models;
use CodeIgniter\Model;
class PnsModel extends Model {
    protected $table = 'pns';
    protected $primaryKey = 'id_pns';
    protected $allowedFields = ['nip','nama_pns','jabatan','id_pd','no_hp'];
    protected $useTimestamps = true;
}