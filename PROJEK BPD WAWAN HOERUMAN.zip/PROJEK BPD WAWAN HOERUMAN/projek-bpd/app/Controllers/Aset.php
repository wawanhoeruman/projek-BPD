<?php
namespace App\Controllers;
use App\Models\AsetModel;

class Aset extends BaseController
{
    // public function index()
    // {
    //     $model = new AsetModel();
    //     $data['aset'] = $model->findAll();
    //     return view('aset/list', $data);
    // }
    public function index()
    {
    $model = new AsetModel();
    
    // ambil keyword dari search
    $keyword = $this->request->getVar('keyword');
    if($keyword){
        $model->like('nama_aset', $keyword)->orLike('kode_aset', $keyword);
    }

    $data = [
        'aset' => $model->paginate(5), // 5 data per halaman
        'pager' => $model->pager,
        'keyword' => $keyword
    ];
    
    return view('aset/list', $data);
    }

    public function tambah()
    {
        return view('aset/tambah');
    }

    public function simpan()
    {
        $model = new AsetModel();
        $rules = [
            'kode_aset' => 'required|is_unique[tb_aset.kode_aset]',
            'nama_aset' => 'required',
            'kategori' => 'required',
            'lokasi' => 'required',
            'nilai_aset' => 'required|numeric'
        ];
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $model->save($this->request->getPost());
        return redirect()->to('/aset');
    }

    public function edit($id)
    {
        $model = new AsetModel();
        $data['row'] = $model->find($id);
        return view('aset/edit', $data);
    }

public function update($id)
{
    $model = new AsetModel();
    $rules = [
        'kode_aset' => "required|is_unique[tb_aset.kode_aset,id,{$id}]",
        'nama_aset' => 'required',
        'kategori' => 'required',
        'lokasi' => 'required',
        'nilai_aset' => 'required|numeric'
    ];
    if (!$this->validate($rules)) {
        // JANGAN pakai back(), paksa balik ke edit/$id biar gak nyasar ke tambah
        return redirect()->to('/aset/edit/'.$id)->withInput()->with('errors', $this->validator->getErrors());
    }
    $model->update($id, $this->request->getPost());
    return redirect()->to('/aset');
}

    public function hapus($id)
    {
        $model = new AsetModel();
        $model->delete($id);
        return redirect()->to('/aset');
    }
}